﻿The Original Author of the oCd Pack is FVDisco.(stopped at 1.8 snapshot)
Models by Sycchenchen, Aijienlement and Zero_Exact.
Some models in the ProTex 1.13+ is from XeKr Highlight Color.
oCd Pack BE was ported by Aijienlement.